// test.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}
#define fstdcall __declspec(dllexport) __stdcall
#define fcdecl __declspec(dllexport)

int fstdcall fvardouble(double &arg1, double  &arg2)
{
	int res = int(arg1-arg2);
	arg1++;
	arg2--;
	return res;
}

int fstdcall fvarint(int &arg1, int &arg2)
{
	int res = arg1-arg2;
	arg1++;
	arg2--;
	return res;
}

int fstdcall fvarstring(LPTSTR arg1)
{
	int res = wcslen(arg1);
	if (res > 1)
	{
		arg1[0] = '*';
		arg1[res-1] = '*';
	}
	return res;
}

int fstdcall fdouble(double arg1, double  arg2)
{
	return int(arg1-arg2);
}

int fstdcall fint(int arg1, int arg2)
{
	return arg1-arg2;
}

int fstdcall fint2(int arg1)
{
	return arg1*2;
}

int fstdcall fstring(LPCTSTR arg1)
{
	return wcslen(arg1);
}

int fcdecl fintcdecl(int arg1)
{
	return arg1*3;
}
