MtmdAcadTabs.arx / MtmdAcadTabs.brx

MtmdAcadTabs is designed to display tabs with names 
of the drawings in AutoCAD / BricsCAD

The distinctive feature of MtmdAcadTabs is the ability to
flexible adjustment of displayed text using AutoLISP.

In particular, instead of the drawing file name, 
you can display the title of the document
from SQL-database of document management system
or form name on specific rules.

Installation instruction:

This version does not have an installer, 
so it is recommended that you deploy the archive
into separate folder, then choose one of the ways
to load module into AutoCAD:

1. add the path to the file MtmdAcadTabs.x.y.arx(brx) in the Startup Suite
(Menu->Tools->Load application->Startup Suite->Add...

2. add this row: 
(arxload "Full_Path\\MtmdAcadTabs.x.y.arx")
into your acad.lsp file

Customizing:

By default, tab caption is name of the drawing without a path.

Edit the file MtmdAcadTabs.lsp to customize tab caption.
See more detailed instructions in the MtmdAcadTabs.lsp

History of changes:

19.06.13 - v.1.2.1

17.08.10 - v.1.2
+ Close a document by clicking the middle mouse button
+ Modules for AutoCAD 2007-2009 and 2010 released

30.12.08-v.1.1
+ Added the ability to define custom commands in the context menu
(see examples in mtmdacadtabs.lsp)

7.10.04.-v.1.02
+ The list of opened documents in the context menu

6.10.04-v.1.01.
* Fixed some bugs

4.10.04-v.1.0 beta

Please direct your comments to:
Mansour Mamkin < mmamkin@mail.ru >
ICQ 30825349